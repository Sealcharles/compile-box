#!/bin/sh

mkdir -p laravel-project/storage/mysql 
mkdir -p laravel-project/storage/logs
mkdir -p laravel-project/storage/app

cd laravel-project

composer global require "laravel/installer"

